clear all
close all
clc


loss = load('loss.his');
figure()
semilogy(loss)

min(loss)