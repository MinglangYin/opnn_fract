"""
Physics-informed Neural Network
Author: Minglang Yin
"""

import sys
sys.path.insert(0,'../../Utils')

import torch
import torch.nn as nn
from functions import *

gc = 2.7
l0 = 0.0125
crackTip = 0.5
B = 92
E = 210.0*1e3
nu = 0.3

mu = 0.5*E/(1 + nu)
lmd = nu*E/((1 - 2*nu)*(1 + nu))
v_del = 5e-3
# mu = 1
# lmd = 1.5

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()

        ## material property tensor
        self.crackTip = 0.5

        self.c11 = E*(1 - nu)/((1 + nu)*(1 - 2*nu))
        self.c22 = E*(1 - nu)/((1 + nu)*(1 - 2*nu))
        self.c12 = E*nu/((1 + nu)*(1 - 2*nu))
        self.c21 = E*nu/((1 + nu)*(1 - 2*nu))
        self.c31 = 0.0
        self.c32 = 0.0
        self.c13 = 0.0
        self.c23 = 0.0
        self.c33 = 0.5*E/(1 + nu)

        # self.weig = weight
        
        self.net = nn.Sequential()
        self.net.add_module('linear_layer_1', nn.Linear(2, 10))
        self.net.add_module('tanh_layer_1', nn.Tanh())
        for num in range(2,8):
            self.net.add_module('linear_layer_%d' %(num), nn.Linear(10, 10))
            self.net.add_module('tanh_layer_%d' %(num), nn.Tanh())
        self.net.add_module('linear_layer_50', nn.Linear(10, 3))

    def forward(self, x):
        return self.net(x)

    def loss_energy(self, x, H_init):
        ## strain energy 
        E_e, E_c = self._get_elas_strain_energy(x, H_init)
        E = (E_e + E_c).mean()

        ## weigthed 
        # E = torch.sum(E*self.weig).sum
        return E

    def loss_bc(self, x_l, x_r, x_up, x_dw):
        y_l, y_r, y_up, y_dw = self.net(x_l), self.net(x_r), self.net(x_up), self.net(x_dw)
        phi_l, phi_r, phi_up, phi_dw = y_l[:, 2], y_r[:, 2], y_up[:, 2], y_dw[:, 2]
        
        phi_l_x = gradients(phi_l, x_l)[0][:, 0]
        phi_r_x = gradients(phi_r, x_r)[0][:, 0]
        phi_up_y = gradients(phi_up, x_up)[0][:, 1]
        phi_dw_y = gradients(phi_dw, x_dw)[0][:, 1]
        
        loss = (phi_l_x**2).mean() + (phi_r_x**2).mean() + (phi_up_y**2).mean() + (phi_dw_y**2).mean()

        return loss

    def _get_lift_sol(self, x):
        y = self.net(x)
        u_net, v_net, phi_net = y[:, 0], y[:, 1], y[:, 2]

        ## lift solution
        u = (1- x[:, 0])*x[:, 0]*u_net
        v = x[:, 1]*(x[:, 1] - 1)*v_net + x[:, 1]*v_del
        phi = phi_net

        return u, v, phi

    def _get_psi(self, x, u, v):
        ## strain
        eps_11, eps_12, eps_22, _, _, _ = self._get_strain_stress(x, u, v)

        ## eigenvalues
        lmd_1 = (eps_11 + eps_22)/2 + torch.sqrt( (eps_11 - eps_22)**2 + 4*(eps_12)**2 )
        lmd_2 = (eps_11 + eps_22)/2 - torch.sqrt( (eps_11 - eps_22)**2 + 4*(eps_12)**2 )

        ## new energy functional
        lmd_sum = lmd_1 + lmd_2
        # print(f'lmd_1: {lmd_1}, lmd_2: {lmd_2}')
        psi_pos = 0.125*lmd*(lmd_sum + torch.abs(lmd_sum))**2 \
            + 0.25*mu*( (lmd_1**2 + torch.abs(lmd_1))**2 + (lmd_2 + torch.abs(lmd_2))**2 )

        psi_neg = 0.125*lmd*(lmd_sum - torch.abs(lmd_sum))**2 \
            + 0.25*mu*( (lmd_1**2 - torch.abs(lmd_1))**2 + (lmd_2 - torch.abs(lmd_2))**2 )

        return psi_pos, psi_neg

    def _get_H(self, H0, psi_pos):
        H_new = torch.max(H0, psi_pos)
        return H_new
    
    def _get_elas_strain_energy(self, x, H_init):
        ## get lifted sol
        u, v, phi = self._get_lift_sol(x)

        ## get gradient
        u_g = gradients(u, x)[0]
        v_g = gradients(v, x)[0]
        phi_g = gradients(phi, x)[0]

        u_x, u_y = u_g[:, 0], u_g[:, 1]
        v_x, v_y = v_g[:, 0], v_g[:, 1]
        phi_x, phi_y = phi_g[:, 0], phi_g[:, 1]
        
        g = (1 - phi)**2

        ## get psi
        psi_pos, psi_neg = self._get_psi(x, u, v)

        ## update H
        H_new = self._get_H(H_init, psi_pos)

        ## get strain and fracture energy
        # E_e = g*psi_pos + psi_neg
        # E_c = 0.5*gc/l0*(phi**2 + l0**2*(phi_x**2 + phi_y**2) ) + g*H_new

        ## alternative formulation
        _, _, _, sig_11, sig_12, sig_22 = self._get_strain_stress(x, u, v)
        E_e = 0.5*g*(sig_11*u_x + sig_22*v_y + sig_12*(u_y + v_x) )
        E_c = 0.5*gc*(phi**2/l0 + l0*(phi_x**2 + phi_y**2)) + g*H_new

        return E_e, E_c


    def _get_strain_stress(self, x, u, v):
        u_g = gradients(u, x)[0]
        v_g = gradients(v, x)[0]
        u_x, u_y = u_g[:, 0], u_g[:, 1]
        v_x, v_y = v_g[:, 0], v_g[:, 1]
        
        ## strain
        eps_11 = u_x
        eps_22 = v_y
        eps_12 = (u_y + v_x)/2
        
        ## stress
        sig_11 = self.c11*u_x + self.c12*v_y
        sig_22 = self.c21*u_x + self.c22*v_y
        sig_12 = 2*self.c33*eps_12
        return eps_11, eps_12, eps_22, sig_11, sig_12, sig_22

def init_H(x):
    init_hist = np.zeros((x.shape[0]))
    dist = np.where(x[:, 0] > crackTip, np.sqrt((x[:, 0] - 0.5)**2 + (x[:, 1] - 0.5)**2), np.abs(x[:, 1] - 0.5))
    H_init = np.where(dist < 0.5*l0, B*gc*0.5*(1 - (2*dist/l0))/l0, init_hist)
    # H_init = np.exp( -np.sqrt( (x[:, 0]-0.5)**2*(np.tanh( (x[:, 0] - 0.5)/l0 ) + 1)/2 + (x[:, 1] - 0.5)**2)/l0 )
    return H_init