"""
Author: Minglang Yin
    Input: [x, y]
    Output: [u, v, phi]
"""

import sys
import os
sys.path.insert(0,'../../Utils')

import torch
import torch.nn as nn
import numpy as np
import time
import random
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import scipy.io

from pinn import *
from plotting import newfig, savefig

import matplotlib
matplotlib.use('Agg') 

torch.manual_seed(123456)
np.random.seed(123456)

def main():
    ## parameters
    device = torch.device(f"cuda:{0}" if torch.cuda.is_available() else "cpu")
    print(device, flush=True)
    epochs = 20000
    lr = 0.001
    v_del = 5e-4
    steps = 10

    num_x = 301
    num_y = 301
    num_b_train = 50    # boundary sampling points
    num_f_train = 5000   # inner sampling points
    path_list = ['./Predictions/']

    x_min, x_max = 0, 1
    y_min, y_max = 0, 1
    asp_ratio = (y_max-y_min)/(x_max-x_min)

    x = np.linspace(x_min, x_max, num=num_x)
    y = np.linspace(y_min, y_max, num=num_y)
    x_grid, y_grid = np.meshgrid(x, y)
    x_2d = np.concatenate((x_grid.flatten()[:,None], y_grid.flatten()[:,None]), axis=1)

    x_in_grid, y_in_grid = np.meshgrid(x[1:-1], y[1:-1])
    x_in_2d = np.concatenate((x_in_grid.flatten()[:,None], y_in_grid.flatten()[:,None]), axis=1)

    ## save init fig
    ## Create Folders
    for path in path_list:
        os.makedirs(path, exist_ok=True)

    ## sampling
    # id_f = np.random.choice(num_x*num_y, num_f_train, replace=False)
    # id_b = np.random.choice(num_x, num_b_train, replace=False) ## Dirichlet

    ## H_init
    H_init = init_H(x_in_2d)

    fig, ax = newfig(2.0, 1.1)
    ax.axis('off') 
    gs0 = gridspec.GridSpec(1, 2)
    gs0.update(top=1-0.06, bottom=1-1/3, left=0.15, right=0.85, wspace=0)
    h = ax.imshow(H_init.reshape(num_x-2, num_y-2), interpolation='nearest', cmap='RdBu_r', origin='lower', aspect=asp_ratio)
    fig.colorbar(h)
    ax.plot(x_in_2d[:,0], x_in_2d[:,1], 'kx', label = 'Data (%d points)' % (x_in_2d.shape[0]), markersize = 4, clip_on = False)
    fig.savefig('./Predictions/phi_init.png')
    plt.close()

    ###########
    x_up = np.vstack((x_grid[-1,:], y_grid[-1,:])).T
    x_dw = np.vstack((x_grid[0,:], y_grid[0,:])).T
    x_l = np.vstack((x_grid[:, 0], y_grid[:, 0])).T
    x_r = np.vstack((x_grid[:, -1], y_grid[:, -1])).T

    ##### Gauss weigtts
    # data = scipy.io.loadmat('../../Xiaoning/points.mat')
    # w = data['www1'][:, 0] # T x 1
    # print(f'w shape: {w.shape}')

    ## set data as tensor and send to device
    x_f_train = torch.tensor(x_in_2d, requires_grad=True, dtype=torch.float32).to(device)
    x_l_train = torch.tensor(x_l, requires_grad=True, dtype=torch.float32).to(device)
    x_r_train = torch.tensor(x_r, requires_grad=True, dtype=torch.float32).to(device)
    x_up_train = torch.tensor(x_up, requires_grad=True, dtype=torch.float32).to(device)
    x_dw_train = torch.tensor(x_dw, requires_grad=True, dtype=torch.float32).to(device)
    H_i_train = torch.tensor(H_init, requires_grad=True, dtype=torch.float32).to(device)
    x_test_tensor = torch.tensor(x_2d, requires_grad=True, dtype=torch.float32).to(device)

    # training
    loss_his = np.zeros((epochs,steps))

    def train(epoch, step, model, optimizer):
        model.train()
        def closure():
            optimizer.zero_grad()
            loss_e = model.loss_energy(x_f_train, H_i_train)
            loss_bc = model.loss_bc(x_l_train, x_r_train, x_up_train, x_dw_train)
            loss = loss_e + 10*loss_bc
            print(f'loading step: {step} epoch {epoch} loss_e:{loss_e:6f}, loss_bc:{loss_bc:6f}', flush=True)
            loss.backward()
            return loss
        loss = optimizer.step(closure)
        loss_value = loss.item() if not isinstance(loss, float) else loss
        loss_his[epoch,step] = loss_value

    ## test
    def test(step, x, model):
        y_pred = model(x)
        Predictions = to_numpy(y_pred[:, 2]).reshape(num_x, num_y)
        name = './Predictions/phi_' + str(step) + '.png'
        fig, ax = newfig(2.0, 1.1)
        field_plot(fig, ax, name, to_numpy(x[:, 0]), to_numpy(x[:, 1]), Predictions)
    
    print('start training...', flush=True)
    tic = time.time()
    for step in range(0, steps):
        ## instantiate model
        Param = dict()
        Param['equ_type'] = 'linear'
        Param['crack_tip'] = 0.5
        Param['v_del'] = v_del*step
        
        model = Model(Param).to(device)
        optimizer = torch.optim.Adam(model.parameters(), lr = lr)

        for epoch in range(0, epochs):    
            if (epoch == 10000):
                optimizer = torch.optim.Adam(model.parameters(), lr = 0.0005)
            elif (epoch == 20000):
                optimizer = torch.optim.Adam(model.parameters(), lr = 0.0001)    
            elif (epoch == 30000):
                optimizer = torch.optim.Adam(model.parameters(), lr = 0.00001)        
            elif (epoch == 40000):
                optimizer = torch.optim.LBFGS(model.parameters())

            train(epoch, step, model, optimizer)

        test(step, x_test_tensor, model)

    toc = time.time()
    print(f'total training time: {int((toc-tic)/60)} min', flush=True)  



    ## save loss
    np.savetxt('loss.his', loss_his)

if __name__ == '__main__':
    main()


















